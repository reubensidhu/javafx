package game;

import javafx.fxml.FXML;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import game.ShipModel.CellValue;

public class GameView extends Group {

    @FXML
    private int rowCount;
    @FXML
    private int columnCount;
    private ImageView[][] cellViews;
    private final Image pacmanRightImage = new Image(getClass().getResourceAsStream("/res/playerShip3_right.png"));
    private final Image pacmanUpImage = new Image(getClass().getResourceAsStream("/res/playerShip3_up.png"));
    private final Image pacmanDownImage = new Image(getClass().getResourceAsStream("/res/playerShip3_down.png"));
    private final Image pacmanLeftImage = new Image(getClass().getResourceAsStream("/res/playerShip3_left.png"));
    private final Image wallImage = new Image(getClass().getResourceAsStream("/res/spaceBuilding_025.png"));
    private final Image bigDotImage = new Image(getClass().getResourceAsStream("/res/powerupBlue_bolt.png"));
    private final Image smallDotImage = new Image(getClass().getResourceAsStream("/res/smalldot.png"));
    public final static double CELL_WIDTH = 30.0;

    public GameView() {
    }

    // make new empty grid
    private void initializeGrid() {
        if (this.rowCount > 0 && this.columnCount > 0) {
            this.cellViews = new ImageView[this.rowCount][this.columnCount];
            for (int row = 0; row < this.rowCount; row++) {
                for (int column = 0; column < this.columnCount; column++) {
                    ImageView imageView = new ImageView();
                    imageView.setX((double) column * CELL_WIDTH);
                    imageView.setY((double) row * CELL_WIDTH);
                    imageView.setFitWidth(CELL_WIDTH);
                    imageView.setFitHeight(CELL_WIDTH);
                    this.cellViews[row][column] = imageView;
                    this.getChildren().add(imageView);
                }
            }
        }
    }

    // update based off of model of grid
    public void update(ShipModel model) {
        if (model.getRowCount() != this.rowCount || model.getColumnCount() != this.columnCount) {
            this.rowCount = model.getRowCount();
            this.columnCount = model.getColumnCount();
            initializeGrid();
        }
        //set the image to correspond with the value of that cell
        for (int row = 0; row < this.rowCount; row++) {
            for (int column = 0; column < this.columnCount; column++) {
                CellValue value = model.getCellValue(row, column);
                if (value == CellValue.WALL) {
                    this.cellViews[row][column].setImage(this.wallImage);
                } else if (value == CellValue.BIGDOT) {
                    this.cellViews[row][column].setImage(this.bigDotImage);
                } else if (value == CellValue.SMALLDOT) {
                    this.cellViews[row][column].setImage(this.smallDotImage);
                } else {
                    this.cellViews[row][column].setImage(null);
                }
                // display pacman
                if (row == model.getPacmanLocation().getX() && column == model.getPacmanLocation().getY() && (ShipModel.getLastDirection() == ShipModel.Direction.RIGHT || ShipModel.getLastDirection() == ShipModel.Direction.NONE)) {
                    this.cellViews[row][column].setImage(this.pacmanRightImage);
                } else if (row == model.getPacmanLocation().getX() && column == model.getPacmanLocation().getY() && ShipModel.getLastDirection() == ShipModel.Direction.LEFT) {
                    this.cellViews[row][column].setImage(this.pacmanLeftImage);
                } else if (row == model.getPacmanLocation().getX() && column == model.getPacmanLocation().getY() && ShipModel.getLastDirection() == ShipModel.Direction.UP) {
                    this.cellViews[row][column].setImage(this.pacmanUpImage);
                } else if (row == model.getPacmanLocation().getX() && column == model.getPacmanLocation().getY() && ShipModel.getLastDirection() == ShipModel.Direction.DOWN) {
                    this.cellViews[row][column].setImage(this.pacmanDownImage);
                }
            }
        }
    }

    public int getRowCount() {
        return this.rowCount;
    }

    public int getColumnCount() {
        return this.columnCount;
    }

}
